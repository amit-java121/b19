package com;

public class TestCustomer {
	
	public Customer createCustomerObject() {
		
		Customer customer = new Customer(1010100101l,1001,"Ajay","pune");
		
		return customer;
	}
	
	public void useCustomerObject() {
		
		Customer cust = createCustomerObject();
		
		cust.setCustomerName("Bijay");
		
		System.out.println(cust.toString());
	}
	
	
	public static void main(String[] args) {
		TestCustomer tc = new TestCustomer();
		tc.useCustomerObject();
	}

}
