package com;

public class C extends B{
	
	public void m1() {
		System.out.println("final method m1 from class C::");
	}
	
	public static void main(String[] args) {
		C c = new C();
		c.m1();
	}

}
