package com;

public final class A {
	
	 final int number = 100;
	 final int age;
	 
	 final static int panNumber;
	 
	 
	 static {
		 panNumber = 10101000;
	 }
	 
	 public A() {
		 age = 25;
	 }
	 
	
	public void test() {
		//number = 200;
		//age = 20;
	}
	
	
	public static void main(String[] args) {
		A a = new A();
	}

	
}
