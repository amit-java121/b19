package com;

public class Customer {
	
	private final long customerAccountNumber;
	private int customerId;
	private String customerName;
	private String customerAddress;
	
	public Customer(long customerAccountNumber, int customerId, String customerName, String customerAddress) {
		super();
		this.customerAccountNumber = customerAccountNumber;
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
	}

	public long getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public int getCustomerId() {
		return customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	@Override
	public String toString() {
		return "Customer [customerAccountNumber=" + customerAccountNumber + ", customerId=" + customerId
				+ ", customerName=" + customerName + ", customerAddress=" + customerAddress + "]";
	}

	

}
