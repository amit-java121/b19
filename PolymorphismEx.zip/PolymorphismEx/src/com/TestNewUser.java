package com;

public class TestNewUser {
	
	public static void main(String[] args) {
		
		NewUser newUser = new NewUser(100, "Bijay", "male", "mumbai", 1818881);
		
	}

}
