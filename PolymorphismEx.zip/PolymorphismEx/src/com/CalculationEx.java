package com;

public class CalculationEx {
	
	public int addition(int a,int b) {
		//int sum = a+b;
		return a+b;
	}
	
	public int addition(int a,int b, int c) {
		
		return a+b+c;
	}
	
	
	public static void main(String[] args) {
		CalculationEx ce = new CalculationEx();
		int result = ce.addition(10, 20,30);
		
		System.out.println(result);
	}

}
