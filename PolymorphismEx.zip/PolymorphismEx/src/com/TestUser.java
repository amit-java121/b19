package com;

public class TestUser {
	
	public void setUserData() {
		User user  = new User(100,"Ajay","male","pune");
		
		
		
		System.out.println(user.toString());
	}
	
	public static void main(String[] args) {
		TestUser tu = new TestUser();
		tu.setUserData();
	}

}
