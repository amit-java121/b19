package com;

public class User {
	
	private int userID;
	private String userName;
	private String gender;
	private String address;
	//private int adhaarNumber;
	
	public User(int userID, String userName, String gender, String address) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.gender = gender;
		this.address = address;
	}
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return "User [userID=" + userID + ", userName=" + userName + ", gender=" + gender + ", address=" + address
				+ "]";
	}
	
	

}
