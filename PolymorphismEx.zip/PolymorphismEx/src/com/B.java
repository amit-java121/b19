package com;

public class B extends A{
	
	public void m1() {
		System.out.println("m1 called from class B");
	}

}
