package com;

public class TestAB {
	public static void main(String[] args) {
		
		//A a = new A();
		B b = new B();
		b.m1();
		
		b.test();
		
	}

}
