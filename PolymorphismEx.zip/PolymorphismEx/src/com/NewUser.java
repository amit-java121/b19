package com;

public class NewUser extends User{
	private int adhaarNumber;
	
	public NewUser(int userID, String userName, String gender, String address,int adhaarNumber) {
		super(userID, userName, gender, address);
		this.adhaarNumber = adhaarNumber;

	}

	public int getAdhaarNumber() {
		return adhaarNumber;
	}

	public void setAdhaarNumber(int adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}
	
	


	

}
