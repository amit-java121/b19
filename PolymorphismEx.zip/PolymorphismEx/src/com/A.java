package com;

public class A {
	
	
	public void test() {
		System.out.println("test::::");
	}
	
	public void m1() {
		System.out.println("m1 called from class A");
	}

}
