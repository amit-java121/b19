package conditionalStmt;

public class A {

	
	public static void main(String[] args) {
		
		int marks = 80;
		
		if(marks >= 35 && marks <=50) {
			System.out.println("u r passed");
			
			
		}else if(marks >= 50 && marks <= 75 ) {

			System.out.println("passed with second division");
		
		}else if(marks >= 75 && marks <= 100) {
			System.out.println("passed with first division");
		
		}else {
			System.out.println("u r failed:::");
			
		}

		
	}
}
