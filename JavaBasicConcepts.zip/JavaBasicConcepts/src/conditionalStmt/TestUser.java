package conditionalStmt;

public class TestUser {
	
	
	public void testUser(int userId,int salary) {
		Test test = new Test();
		test.validateUserData(userId, salary);
		
	}
	
	public static void main(String[] args) {
		
		TestUser tu = new TestUser();
		tu.testUser(10,51000);
		
		
	}

}
