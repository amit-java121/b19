package conditionalStmt;

public class Test {
	
	public void validateUserData(int userId,int salary) {
		
		System.out.println("some code here:::");
		
		
		if(userId > 0 && salary > 50000) {
			System.out.println("user is valid");
			
//			if(salary > 50000) {
//				System.out.println("salary == "+salary);
//			}else {
//				System.out.println("user salary is less than 50k "+salary);
//			}
			
			
		}else {
			System.out.println("user is not found:: user id="+userId);
		}
		
		
		
	}

}
