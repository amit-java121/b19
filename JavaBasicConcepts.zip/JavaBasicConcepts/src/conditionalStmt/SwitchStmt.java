package conditionalStmt;

public class SwitchStmt {
	
	public void m1(int num) {
		
		switch (num) {
		
		case 100:
			System.out.println(" num value "+num);
			break;
		case 200:
			System.out.println(" num value "+num);
			break;
			
		case 300:
			System.out.println(" num value "+num);
			break;
		case 400:
			
			
			System.out.println(" num value "+num);
			break;

		default:
			System.out.println("default case executed:::");
			break;
		}
	}
	


	
	public static void main(String[] args) {
		SwitchStmt ss = new SwitchStmt();
		ss.m1(400);
	}
}
