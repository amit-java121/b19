package loops;

public class ArrayEx {
	
	public static void main(String[] args) {
		
		int[] aa = {10,20,30,40,50,60};
		
		String[] str = new String[5];
		str[0] = "abc";
		str[1] = "abc1";
		str[2] = "abc2";
		str[3] = "abc3";
		str[4] = "abc4";
		
//		for(int i = 0; i<aa.length; i++) {
//			System.out.println(aa[i]);
//		}
		
		for(int a = 0; a<str.length; a++) {
			System.out.println(str[a]);
		}
		
		
	}

}
