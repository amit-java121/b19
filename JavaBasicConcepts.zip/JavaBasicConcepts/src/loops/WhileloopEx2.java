package loops;

public class WhileloopEx2 {
	
	public static void main(String[] args) {
		
		int a = 10;
		
		while(a < 15) {
			System.out.println("while loop executed::");
			
			a++;
		}
		
		
	}

}
