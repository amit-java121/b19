package loops;

public class DoWhileEx {
	
	public static void main(String[] args) {
		
		int a =20;
		do {
			
			System.out.println("do executed:::");
			a--;
		}while(a > 15);
		
	}

}
