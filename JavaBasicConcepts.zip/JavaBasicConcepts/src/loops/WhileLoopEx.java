package loops;

public class WhileLoopEx {
	
	public static void main(String[] args) {
		
		boolean flag = true;
		int age = 10;
		while(flag) {
			System.out.println("inside while loop::");
			
			flag = checkAge(age);
			age++;
		}
		
	}
	
	public static boolean checkAge(int age) {
		System.out.println("some code here::");
		if(age > 25) {
			return false;
		}else {
			return true;
		}
		
	}

}
