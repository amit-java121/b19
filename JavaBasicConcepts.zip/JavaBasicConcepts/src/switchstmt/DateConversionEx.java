package switchstmt;

public class DateConversionEx {
	
	
	public String dateConversion(String date) {
		String monthName = date.substring(3, 6);
		System.out.println("month name "+monthName);
		
		String monthNumber = convertMonthNameIntoNum(monthName);
		
		String convertedDate = date.replace(monthName, monthNumber);
		
		return convertedDate;
	}
	
	
	public String convertMonthNameIntoNum(String monthName) {
		
		String month=null;
		
		switch (monthName) {
		case "JAN":
			month = "01";
			break;
		case "FEB":
			month = "02";
			break;
			
		case "MAR":
			month = "03";
				break;
		case "APR":
			month = "04";
		break;
		case "MAY":
			month = "05";
			break;
			
		case "JUN":
			month = "06";
			break;

		default:
			month = "13";
			break;
		}
		return month;
	}
	
	
	public static void main(String[] args) {
		
		//14-JUN-2022
		//14-06-2022
		DateConversionEx dce = new DateConversionEx();
		String convertedDate = dce.dateConversion("20-ABC-2022");
		
		String monthNum = convertedDate.substring(3,5);
		
		if(monthNum.equals("13")) {
			System.out.println("Input date is wrong!!!!");
		}else {
			System.out.println("convertedDate "+convertedDate);
		}
		
		
		
	}

}
