package com.methods;

public class TestMethods3 {
	
	public boolean verifyUserCredentials(String userName,String password) {
		//to write a logic to check username and password
		
		if(userName.equals("amit") && password.equals("amit123")) {
			return true;
		}else {
			return false;
		}
		
	}

}
