package com.methods;

public class TestMethods {
	
	
	public int add(int a,int b) {
		int sum = a+b;
		
		return sum;
	}
	
	public static void main(String[] args) {
		//10,15
		//25
		TestMethods tm = new TestMethods();
		
		int result= tm.add(10,15);
		
		System.out.println("result::::: "+result);
		
	}

}
