package com.methods;

public class TestMethods4 {
	
	
	
	public static void main(String[] args) {
	
		TestMethods3 tm3 = new TestMethods3();
		boolean flag = tm3.verifyUserCredentials("amit", "amit123");
		
		if(flag) {
			System.out.println("you are logged in");
		}else {
			System.out.println("your user name and password is incorrect please try agian!!");
		}
		
	}

}
