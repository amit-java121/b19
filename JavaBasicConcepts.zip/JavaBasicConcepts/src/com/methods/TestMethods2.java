package com.methods;

public class TestMethods2 {
	
	
	public int add(int a,int b) {
		int sum = a+b;
		
		return sum;
	}
	
	
	public int multiply(int num,int a,int b) {
	
		int sum = add(a,b);
		int finalResult = sum*num;
		
		return finalResult;
	}
	
	
	public static void main(String[] args) {

		TestMethods2 tm = new TestMethods2();
      
		int result = tm.multiply(100,10,15);
      
      
		System.out.println(result);
	}

}
