package com;

public class A {
	
	int a = 100;
	int b= 200;
	boolean flag; 
	char c='a';
	byte bb = 120;
	short s = 32676;
	int ii = 1919919199;
	long l = 9191991919191991919l;
	float f = 12.098f;
	double d = 12345.988383883d;
	
	B obj;
	
	
		
	
	public void add() {
		
		int sum = a+b;
		System.out.println(sum);
		
	}
	
	
	public static void main(String[] args) {
		System.out.println("main method called::::");
		
		A a = new A();
		a.add();
	}
	
	
	
}


