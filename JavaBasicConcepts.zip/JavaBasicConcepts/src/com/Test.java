package com;

public class Test {
	
	public static void main(String[] args) {
		System.out.println("hello expert");
	
		add();
	}
	
	
	public static void add() {
		int sum = 10+10;
		System.out.println(sum);
	}

}
