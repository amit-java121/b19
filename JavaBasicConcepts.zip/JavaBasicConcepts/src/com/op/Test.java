package com.op;

public class Test {

	public static void main(String[] args) {

		// int a =10;

//		System.out.println(a);//10
//		System.out.println(++a);//11
//		System.out.println(a);//11//10
//		System.out.println(a++);//11
//		System.out.println(a);//12//10

//		int b = 10;
//		
//		if(a == b) {
//			System.out.println("if block executed:::");
//		}else {
//			System.out.println();
//		}

//		int age = 25;
//		if(age != 25) {
//			System.out.println("your are::::::");
//		}else {
//			System.out.println("hhshshshs");
//			
//		}

		// && ||

		int age = 20;
		String name = "xpertit123";

//		if(age > 25 || name.equals("xpertit")) {
//		
//			System.out.println("if condition executed:::");
//		}

		if (!name.equals("xpertit")) {
			System.out.println("inside if::");
		}

		// ? :

		int a = 10;
		int b = 20;

		int value = (a < b) ? 100 : 200;

		System.out.println(value);

		int val = 0;

		if (a < b) {
			val = 100;
		} else {
			val = 200;
		}
		System.out.println(val);

	}

}
