package com;

public class B {

}
