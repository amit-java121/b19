package com;

public class TestStaticEx {
	
	
	public void m1() {
		VariablesEx vee = new VariablesEx();
		System.out.println(VariablesEx.mobileNumber);
		
		System.out.println(vee.age);
		
	}
	
	public static void main(String[] args) {
		TestStaticEx tse = new TestStaticEx();
		tse.m1();
	}

}
