package com;

public class VariablesEx {
	
	int age = 25;//instance variables//Global 
	static int mobileNumber= 191991991;// static variables
	
	
	public void test() {
		int age = 30;//local variables
		System.out.println(age);//30
	}
	
	public void test2() {
	
		System.out.println(age);//25
	}
	
	
	
	public static void main(String[] args) {
		VariablesEx ve = new VariablesEx();
		ve.test();
		ve.test2();
	}

}
