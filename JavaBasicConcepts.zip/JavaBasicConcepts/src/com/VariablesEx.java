package com;

public class VariablesEx {
	
	int age = 25;//instance variables//Global 
	static int mobileNumber= 191991991;// static variables
	
	
	public void test() {
		int age = 30;//local variables
		System.out.println(age);//30
	}
	
	public void test2() {
	
		System.out.println(age);//25
		System.out.println(mobileNumber);
	}
	
	
	
	public static void test3() {
		
		VariablesEx ve = new VariablesEx();
		System.out.println(ve.age);//25
		
		
		System.out.println(mobileNumber);
	}
	
	public static void main(String[] args) {
		VariablesEx ve = new VariablesEx();
		ve.test();
		ve.test2();
	}

}
