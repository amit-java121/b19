package methods;

public class Process {
	
	public void test() {
		System.out.println("test method execution started::");
		
		synchronized(this) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("thread resumed their jon");
		
	}
	
	
	public void test2() {
		System.out.println("test2 method execution started::");
		
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//notify
		synchronized (this) {
			notify();
		}
		
		System.out.println("notify called:::");
		
		
	}


}
