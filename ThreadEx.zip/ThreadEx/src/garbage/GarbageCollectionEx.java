package garbage;

public class GarbageCollectionEx {
	
	public void finalize() {
		System.out.println(Thread.currentThread().getName());
		System.out.println("object garbage collected:: or onject reference destoroyed");
	}
	
	public void test() {
		System.out.println("test called:::");
	}
	
	public static void main(String[] args) {
		GarbageCollectionEx gce = new GarbageCollectionEx();
		GarbageCollectionEx gce2 = new GarbageCollectionEx();
		gce2.test();

		gce = null;
		gce2 = null;
		
		
		
		System.gc();
	}

}
