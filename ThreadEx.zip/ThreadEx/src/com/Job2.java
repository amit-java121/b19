package com;

public class Job2 extends Thread{
	
	@Override
	public void run() {
		System.out.println("Job Thread ="+Thread.currentThread().getName());
		for(int i=10; i<20; i++) {
			System.out.println("i= "+i);
		}
	}

}
