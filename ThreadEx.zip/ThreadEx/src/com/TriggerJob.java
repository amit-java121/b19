package com;

public class TriggerJob {
	
	public static void main(String[] args) {
		
		System.out.println("Thread before first loop ="+Thread.currentThread().getName());
		for(int i=0; i<10;i++) {
			System.out.println("i "+i);
		}
		
		Job job = new Job();
		job.run();
		
		System.out.println("Thread before third loop ="+Thread.currentThread().getName());
		for(int i=20; i<30;i++) {
			System.out.println("i "+i);
		}
		
	}

}
