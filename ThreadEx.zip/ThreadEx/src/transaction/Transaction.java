package transaction;

public class Transaction extends Thread{
	
	static int balance = 2000;

	@Override
	public void run() {
		for(int i=0; i<5; i++) {
		  withdraw(200);
		}
	}

	private static synchronized void withdraw(int amount) {
		System.out.println("thread trying to withdraw::"+Thread.currentThread().getName());
		
		if(balance > amount) {
			balance = balance - amount;
			System.out.println("available amount "+balance);
		}else {
			System.out.println("insufficient balance::");
		}
		
	}
	
}
