package transaction;

public class TriggerTasks {
	
	
	public static void main(String[] args) {
		PrintNumber pn = new PrintNumber();
		
		Task1 task1 = new Task1(pn);
		task1.start();
		
		
		Task2 task2 = new Task2(pn);
		task2.start();
		
	}

}
