package com.it.dao;

import com.it.model.Customer;

public interface CustomerDao {

	Customer getCustomerByEmailId(String username);

}
