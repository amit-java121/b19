package com.it.dao;

public interface CustomerDao {

}
