package com.it.dao;

import java.util.List;

import com.it.model.Customer;

public interface CustomerDao {

	Customer getCustomerByEmailId(String username);

	boolean saveCustomerData(Customer customer);

	List<Customer> getAllCustomersData();

	boolean deleteCustomerById(int id);

	Customer getCustomerByEmailId(int id);

}
