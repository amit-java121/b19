package com.it.dao;

import java.util.List;

import com.it.model.Customer;

public interface CustomerDao {

	Customer getCustomerByEmailId(String username);

	boolean saveCustomerData(Customer customer);

	List<Customer> getAllCustomersData();

	void deleteCustomerById(int id);

}
