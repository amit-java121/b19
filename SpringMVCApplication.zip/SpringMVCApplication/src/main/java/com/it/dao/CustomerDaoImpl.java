package com.it.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.Customer;


@Repository
public class CustomerDaoImpl implements CustomerDao{
	
	@Autowired
	SessionFactory sessionFactory;

	public Customer getCustomerByEmailId(String username) {
		
		Session session = sessionFactory.openSession();
		
		Query query = session.createQuery("from Customer where customer_email=?");
		Customer customer= (Customer)query.setParameter(0, username).getSingleResult();
		
		System.out.println("Customer from DB:: "+customer.toString());
	
		return customer;
	}

}
