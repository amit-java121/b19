package com.it.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.it.model.Customer;


@Repository
@Transactional
public class CustomerDaoImpl implements CustomerDao{
	
	@Autowired
	SessionFactory sessionFactory;

	public Customer getCustomerByEmailId(String username) {
		
		Session session = sessionFactory.openSession();
		
		Query query = session.createQuery("from Customer where customer_email=?");
		Customer customer= (Customer)query.setParameter(0, username).getSingleResult();
		
		System.out.println("Customer from DB:: "+customer.toString());
	
		return customer;
	}

	public boolean saveCustomerData(Customer customer) {
		try {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		session.save(customer);
		tr.commit();
		return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	@SuppressWarnings({ "unchecked", "deprecation" })
	public List<Customer> getAllCustomersData() {
		
		Session session = sessionFactory.getCurrentSession();
	
		List<Customer> listOfCustomers = session.createCriteria(Customer.class).list();
		
		return listOfCustomers;
	}

	public void deleteCustomerById(int id) {
		Session session = sessionFactory.getCurrentSession();
		Customer customer = session.get(Customer.class, id);
		session.delete(customer);
	}

}
