package com.it.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CustomerController {
	
	@GetMapping("/")
	public String loginPage() {
	
		System.out.println("loginpage called::");
		return "login";
	}

}
