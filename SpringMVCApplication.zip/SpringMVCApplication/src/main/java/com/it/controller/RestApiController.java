package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.model.User;
import com.it.service.RestApiService;

@Controller
public class RestApiController {
	
	@Autowired
	RestApiService restApiService;
	
	@GetMapping("/call-api")
	public String callApi(Model model) {
		
		List<User> listOfUsers = restApiService.getAllData();
		model.addAttribute("data", listOfUsers);
		return "login";
	}
	
	@GetMapping("/delete-api-user")
	public void deleteUser(@RequestParam("id") int id) {
		restApiService.deleteUser(id);
	}

}
