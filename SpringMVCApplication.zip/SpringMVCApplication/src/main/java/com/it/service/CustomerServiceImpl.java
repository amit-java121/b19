package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.CustomerDao;
import com.it.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerDao customerDao;

	public boolean verifyCustomerCredentials(String username, String password) {
		
		Customer customer = customerDao.getCustomerByEmailId(username);
		
		if(customer.getCustomerEmail().equals(username) && customer.getCustomerPassword().equals(password)) {
			return true;
		}else {
			return false;
		}
		
	}

	public boolean saveCustomerData(Customer customer) {
		
		return customerDao.saveCustomerData(customer);
	}

	public List<Customer> getAllCustomersData() {
		
		return customerDao.getAllCustomersData();
	}

	public boolean deleteCustomerById(int id) {
		
		return customerDao.deleteCustomerById(id);
		
	}

	public Customer getCustomerById(int id) {
		
		return customerDao.getCustomerByEmailId(id);
	}

}
