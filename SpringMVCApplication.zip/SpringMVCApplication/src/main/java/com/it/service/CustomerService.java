package com.it.service;

import java.util.List;

import com.it.model.Customer;

public interface CustomerService {

	boolean verifyCustomerCredentials(String username, String password);

	boolean saveCustomerData(Customer customer);

	List<Customer> getAllCustomersData();

	void deleteCustomerById(int id);


}
