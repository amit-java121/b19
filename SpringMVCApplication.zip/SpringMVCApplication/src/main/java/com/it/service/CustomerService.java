package com.it.service;

public interface CustomerService {

	boolean verifyCustomerCredentials(String username, String password);

}
