package com.it.service;

import java.util.List;

import com.it.model.Customer;

public interface CustomerService {

	boolean verifyCustomerCredentials(String username, String password);

	boolean saveCustomerData(Customer customer);

	List<Customer> getAllCustomersData();

	boolean deleteCustomerById(int id);

	Customer getCustomerById(int id);


}
