package com.it.service;

public interface CustomerService {

}
