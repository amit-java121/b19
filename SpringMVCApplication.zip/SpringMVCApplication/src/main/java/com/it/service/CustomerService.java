package com.it.service;

import com.it.model.Customer;

public interface CustomerService {

	boolean verifyCustomerCredentials(String username, String password);

	void saveCustomerData(Customer customer);


}
