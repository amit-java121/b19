package com.it.service;

import java.util.Arrays;
import java.util.List;


import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.it.model.User;

@Component
public class RestApiService {
	
	private RestTemplate getRestTemplate() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		List<HttpMessageConverter<?>> msgConverter = restTemplate.getMessageConverters();
		msgConverter.add(new MappingJackson2HttpMessageConverter());
		
		return restTemplate;
	}

	public List<User> getAllData() {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<?> entity = new HttpEntity<Object>(headers);
			
		 ResponseEntity<User[]> response = getRestTemplate().exchange("http://localhost:9090/user/getAllUsers/", HttpMethod.GET, entity, User[].class);
		
		User[] arrayOfCustomer = response.getBody();
		List<User> listOfUser = Arrays.asList(arrayOfCustomer);
			
		return listOfUser;
		}

	public void deleteUser(int id) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<?> entity = new HttpEntity<Object>(headers);
		
		ResponseEntity<String> resposne = getRestTemplate().exchange("http://localhost:9090/user/delete/"+id+"", HttpMethod.DELETE, entity,String.class);
		
		System.out.println("status "+resposne.getStatusCode());
		System.out.println("msg "+resposne.getBody());
		
	}
	
	
	

}
