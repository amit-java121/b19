package com.it.model;

public class User {
	

	private int customerId;
	private String customerName;
	private String customerEmail;
	private String customerPassword;
	private String gender;
	private String country;
	private long contactNumber;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	@Override
	public String toString() {
		return "User [customerId=" + customerId + ", customerName=" + customerName + ", customerEmail=" + customerEmail
				+ ", customerPassword=" + customerPassword + ", gender=" + gender + ", country=" + country
				+ ", contactNumber=" + contactNumber + "]";
	}
	
	

}
