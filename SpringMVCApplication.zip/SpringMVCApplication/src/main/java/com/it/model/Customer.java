package com.it.model;

public class Customer {

}
