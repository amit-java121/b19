package com;

public class StringBufferEx {
	
	public static void main(String[] args) {
		String str = "hello";//olleh
//		char[] strarray = str.toCharArray();
//		
//		for(int i=strarray.length-1; i>=0; i-- ) {
//			System.out.print(strarray[i]);
//		}
		
		for(int i=str.length()-1; i>=0; i--) {
			System.out.print(str.charAt(i));
		}
		
		StringBuffer sb1 = new StringBuffer(str);
		System.out.println("reverse:: "+sb1.reverse());
		
		
		StringBuffer sb = new StringBuffer("hello");
		//System.out.println(sb);
		
		//sb.append(" xpert it");
		
		//System.out.println(sb);
		
		
		//System.out.println(sb.delete(2, 3));
		//System.out.println(sb.insert(4, "AA"));
		//System.out.println(sb.reverse());
		
		sb.ensureCapacity(1000);
		System.out.println(sb.capacity());
	}

}
