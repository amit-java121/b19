package com;

public class StringBufferEx {
	
	public static void main(String[] args) {
		
		StringBuffer sb = new StringBuffer("hello");
		//System.out.println(sb.capacity());
		//sb.append("xpert it");
		//System.out.println(sb);
		
		//System.out.println(sb.capacity());
		//System.out.println(sb.indexOf("l"));
		//System.out.println(sb.length());
		//System.out.println(sb.delete(1, 3));
		//System.out.println(sb.insert(2, "AA"));
		// sb.setCharAt(2, 'D');
		System.out.println(sb.reverse());

		
	}

}
