package com;

public class Test {
	
	public static void main(String[] args) {
		
//		String str = "hello";
//		  System.out.println("before::"+str);
//		  str.concat("ajay");
//		  System.out.println(str);//helloajay
		  
		  
		  String str = "hello";
		  System.out.println("before::"+str);
		
		  String str2 =  str.concat("ajay");
		  System.out.println(str2);
		
		
	}
	
	

}
