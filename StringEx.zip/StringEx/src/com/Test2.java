package com;

public class Test2 {
	
	public static void main(String[] args) {
		String str = "hello";
		String str1 = "hello";
		
		String str2 =  new String("hello");
		String str3 =  new String("hello");
		
		//equals//check content only
		// == //check references
		
		System.out.println(str.equals(str1));//true
		System.out.println(str.equals(str2));//true/false
		System.out.println(str2.equals(str3));//true

		
		System.out.println(str == str1);//true
		System.out.println(str2 == str3);//true/false
		
		System.out.println(str.hashCode());
		System.out.println(str2.hashCode());
		
		Test2 test = new Test2();
		Test2 test2 = new Test2();
		System.out.println(test);
		System.out.println(test2);
		
		
	}

}
