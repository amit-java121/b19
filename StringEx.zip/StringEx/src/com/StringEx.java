package com;

public class StringEx {
	
	public static void main(String[] args) {
		
		String str ="hello";
		String str3 = "hello";
		
		//String str2 = new String("Hello");
		//String str4 = new String("hello");
		
		String s = str.concat(" xpert it");//hello xpert it
		
		System.out.println(str);
		System.out.println(s);
		
		
//		System.out.println(str==str3);
//		
//		System.out.println(str==str2);
////		
//		System.out.println(str.equals(str2));
////		
//		System.out.println(str.equals(str4));
//		
		//System.out.println(str2 == str4);
		//System.out.println(str2.equalsIgnoreCase(str4));
		
	}

}
