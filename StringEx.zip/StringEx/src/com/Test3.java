package com;

public class Test3 {
	
	public static void main(String[] args) {
		
		String str = "hello";
		String str1 = " hello";
//
//		System.out.println(str.equals(str1));
		
		//System.out.println(str.charAt(2));
		//System.out.println(str.compareTo(str1));
		
		//String str2 = str.concat(str1);
		
		//System.out.println(str2);
		
		//System.out.println(str.contentEquals("hello"));
		//System.out.println(str.endsWith("h"));
		
		//System.out.println(str.equalsIgnoreCase(str1));
		//System.out.println(str.equals(str1));
		
		//System.out.println(str.indexOf('e'));
		
		//System.out.println(str.isBlank());
		//System.out.println(str.isEmpty());
		
		//System.out.println(str.length());
		
		//System.out.println(str.replace("ll", "LL"));
		//System.out.println(str1.trim().equals(str));
		
		//System.out.println(str.substring(2, 4));
		System.out.println(str.substring(2));
		
	}

}
