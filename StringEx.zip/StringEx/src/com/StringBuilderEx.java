package com;

public class StringBuilderEx {
	public static void main(String[] args) {
		
		StringBuilder sb = new StringBuilder("hello");
		//System.out.println(sb);
		//sb.append(" ajay");
		
		//System.out.println(sb);
		System.out.println(sb.reverse());
		
	}

}
