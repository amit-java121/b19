package mref;

import java.util.ArrayList;
import java.util.Optional;

public class TestOptional {
	
	public Optional<ArrayList<String>> prepareData() {
		
		ArrayList<String> list = null;
		
		//from DB while loop
		//database down
		list = new ArrayList<String>();
		list.add("abc");
		list.add("xyz");
		
		
		return Optional.ofNullable(list);
		
		
	}
	
	public void filterData() {
		
		Optional<ArrayList<String>> optionalList = prepareData();
	
		if(optionalList.isPresent()) {
		ArrayList<String> list = optionalList.get();
		
		for(String obj:list) {
			
			if(obj.equals("abc")) {
				System.out.println("remove this element");
			}else {
				System.out.println("dont remove this element");
			}
		}
		}else {
			System.out.println("else executed:::");
		}
	}
	
	public static void main(String[] args) {
		TestOptional to = new TestOptional();
		to.filterData();
	}

}
