package mref;

@FunctionalInterface
public interface IAdd {
	
	public int add(int a,int b);

}
