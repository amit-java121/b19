package mref;

public class TestAdd {
	
//	public static int addition(int a,int b) {
//	//logic
//		return a+b;
//	}
	
	public int addition(int a,int b) {
		//logic
			return a+b;
	}
	
	public static void main(String[] args) {
		
		IAdd ai= (a,b) -> a+b; 
		 int sum = ai.add(10, 10);
		 System.out.println(sum);
		 
		 //////////////////
		TestAdd ta = new TestAdd();
//		 IAdd mAi = TestAdd::addition;
//		 int result = mAi.add(20, 20);
//		 System.out.println(result);
		
		IAdd mAi = ta::addition;
		 int result = mAi.add(20, 20);
		 System.out.println(result);
		
	}

}
