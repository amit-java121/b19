package com;
@FunctionalInterface
public interface AI {
	
	int add(int a,int b);
	//int subtract(int a,int b);
}
