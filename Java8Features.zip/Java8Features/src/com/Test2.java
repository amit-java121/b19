package com;

public class Test2{
	
	public static void main(String[] args) {
		
		AI2 ai2 = (str1,str2) -> {
			
			
			
			return str1.equalsIgnoreCase(str2);
		};
		System.out.println(ai2.compareString("xpertit", "xpert"));
		
		System.out.println(ai2.compareString("xpertit", "xpertit"));
		
	}
	

}


