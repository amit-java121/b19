package com;

public class Test {
	
	public static void main(String[] args) {
		
		
		AI ai = (a,b) -> a+b;
		int sum = ai.add(10, 20);
		System.out.println(sum);
		
		

		AI ai1 = (a,b) -> a*b;
		int multiply = ai1.add(10, 20);
		System.out.println(multiply);
	}

}
