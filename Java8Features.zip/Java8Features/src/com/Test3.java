package com;

public class Test3 implements AI2{

	@Override
	public boolean compareString(String str1, String str2) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	public void test() {
		AI2.m2();
		m1();
	}

}
