package com;
@FunctionalInterface
public interface AI2 {
	
	public boolean compareString(String str1,String str2);
	
	//static and default
	
	default void m1() {
		System.out.println("write common logic");
	}
	
	public static void m2() {
		System.out.println("write our logic");
	}
	
	@Override
	String toString();

}
