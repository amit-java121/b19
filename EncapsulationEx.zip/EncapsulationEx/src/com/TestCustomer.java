package com;

public class TestCustomer {
	
	public static Customer setDataInCutomerObj() {
		Customer customer = new Customer(100,"ajay",25,"pune");
		
		return customer;
	}
	
	public static Customer2 setDataInCutomer2Obj() {
		Customer2 customer2 = new Customer2();
		
		customer2.setCustomerAddress("Pune");
		customer2.setCustomerAge(25);
		
		return customer2;
	}
	
	public static void main(String[] args) {
		
//		Customer customer = setDataInCutomerObj();
//		System.out.println(customer.getCustomerName());
		
		Customer2 cust2 = setDataInCutomer2Obj();
		cust2.setCustomerAddress("mumbai");
		
		
		//System.out.println(cust2.toString());
		
	}

}
