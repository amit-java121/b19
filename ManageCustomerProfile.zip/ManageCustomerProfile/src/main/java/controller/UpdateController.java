package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Customer;
import service.CustomerService;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/update")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String customerEmail = request.getParameter("custEmail");
		if(customerEmail == null) {
			//it will be called when user coming from success jsp 
			int customerId = Integer.valueOf(request.getParameter("id"));
			
			CustomerService customerService = new CustomerService();
			Customer customer = customerService.getCustomerById(customerId);
			
			if(customer != null) {
				request.setAttribute("customer", customer);
				RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
				rd.forward(request, response);
			}else {
				request.setAttribute("message", "Due to some network issue you can't update custoemr record. Please try after some time.");
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}
		}else {
			//coming from update jsp
			Customer customer = new Customer();
			customer.setCustomerName(request.getParameter("custName"));
			customer.setCustomerEmail(request.getParameter("custEmail"));
			customer.setContactNumber(Long.valueOf(request.getParameter("custContact")));
			customer.setGender(request.getParameter("gender"));
			customer.setCountry(request.getParameter("country"));
			
			CustomerService customerService = new CustomerService();
			boolean flag = customerService.updateCustomer(customer);
			
			if(flag) {
				List<Customer> listOfCustomers = customerService.getAllCustomersData();
				request.setAttribute("list", listOfCustomers);
				request.setAttribute("message", "Customer has been updated successfully!!!");
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			}else {
				request.setAttribute("message", "Customer could not update due to some issue please try after some time.");
				request.setAttribute("customer", customer);
				RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
				rd.forward(request, response);
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
