package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Customer;
import service.CustomerService;

/**
 * Servlet implementation class SaveController
 */
@WebServlet("/save")
public class SaveController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveController() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		String custName = request.getParameter("custName");
//		request.getParameter("password");
//		request.getParameter("custEmail");
//		request.getParameter("custContact");
//		request.getParameter("gender");
//		request.getParameter("country");
//		
		Customer customer = new Customer();
		customer.setCustomerName(request.getParameter("custName"));
		customer.setCustomerEmail(request.getParameter("custEmail"));
		customer.setCustomerPassword(request.getParameter("password"));
		customer.setContactNumber(Long.valueOf(request.getParameter("custContact")));
		customer.setGender(request.getParameter("gender"));
		customer.setCountry(request.getParameter("country"));
		
		CustomerService customerService = new CustomerService();
		String msg = customerService.saveCustomerDetails(customer);
		
		if(msg.equals("success")) {
			request.setAttribute("msg", "Your profile has been created successfully!!!");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}else if(msg.equals("duplicate")) {
			request.setAttribute("customer", customer);
			request.setAttribute("message", "Your email is duplicate please try to use another!!");
			RequestDispatcher rd = request.getRequestDispatcher("signup.jsp");
			rd.forward(request, response);
			
		}else {
			request.setAttribute("message", "Due to some network issue your profile has not been created. Please try after some time.");
			RequestDispatcher rd = request.getRequestDispatcher("signup.jsp");
			rd.forward(request, response);
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
