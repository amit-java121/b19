package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Customer;

public class CustomerDao {
	
	public Customer fetchUserCredentialsFrmDB(String userEmail) {
		    Customer customer  = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select customer_email,customer_password from login_tbl where customer_email='"+userEmail+"'");
			 
			while(rs.next()) {
				customer = new Customer();
				String username = rs.getString("customer_email");
				String password = rs.getString("customer_password");
				customer.setCustomerEmail(username);
				customer.setCustomerPassword(password);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return customer;
	}
	
	
	public String saveCustomerDetails(Customer customer) {
		String msg = "";
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
		PreparedStatement pstmt = conn.prepareStatement("insert into login_tbl(customer_name,customer_email,customer_password,gender,country,customer_contact_no) values(?,?,?,?,?,?)");
		
		pstmt.setString(1, customer.getCustomerName());
		pstmt.setString(2, customer.getCustomerEmail());
		pstmt.setString(3, customer.getCustomerPassword());
		pstmt.setString(4, customer.getGender());
		pstmt.setString(5, customer.getCountry());
		pstmt.setLong(6, customer.getContactNumber());
		
		int i = pstmt.executeUpdate();
		System.out.println("i "+i);
		if(i > 0) {
			msg  = "success";
		}
		
	}catch(SQLException se) {
		msg = "duplicate";
		se.printStackTrace();
	}
	catch(Exception e) {
		msg  ="networkissue";
		e.printStackTrace();
	}
	
	return msg;
}
	
	
	public List<Customer> fetchAllCustomersData() {
		
		List<Customer> listOfCustomers = new ArrayList<Customer>();
	    
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from login_tbl");
		 
		while(rs.next()) {
			Customer customer  = new Customer();
			customer.setCustomerId(rs.getInt("customer_id"));
			customer.setCustomerName(rs.getString("customer_name"));
			customer.setCustomerPassword(rs.getString("customer_password"));
			customer.setCustomerEmail(rs.getString("customer_email"));
			customer.setContactNumber(rs.getLong("customer_contact_no"));
			customer.setCountry(rs.getString("country"));
			customer.setGender(rs.getString("gender"));
			
			listOfCustomers.add(customer);
		}
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return listOfCustomers;
}

	
	public boolean deleteCustomerById(int customerId) {
		 boolean flag = false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
			Statement stmt = conn.createStatement();
			int i= stmt.executeUpdate("delete from login_tbl where customer_idd="+customerId);
			 System.out.println("i "+i);
			 
			 if(i > 0) {
				 flag = true;
			 }
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}


	public Customer getCustomerById(int customerId) {
		
		Customer customer = new Customer();
	    
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from login_tbl where customer_id="+customerId);
			 
			while(rs.next()) {
				customer.setCustomerId(rs.getInt("customer_id"));
				customer.setCustomerName(rs.getString("customer_name"));
				customer.setCustomerPassword(rs.getString("customer_password"));
				customer.setCustomerEmail(rs.getString("customer_email"));
				customer.setContactNumber(rs.getLong("customer_contact_no"));
				customer.setCountry(rs.getString("country"));
				customer.setGender(rs.getString("gender"));
				
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return customer;
	}


	public boolean updateCustomer(Customer customer) {
	 boolean flag = false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
			PreparedStatement pstmt = conn.prepareStatement("update login_tbl set customer_name=?,gender=?,country=?,customer_contact_no=? where customer_email=?");
			
			pstmt.setString(1, customer.getCustomerName());
			pstmt.setString(2, customer.getGender());
			pstmt.setString(3, customer.getCountry());
			pstmt.setLong(4, customer.getContactNumber());
			pstmt.setString(5, customer.getCustomerEmail());
			
			int i = pstmt.executeUpdate();
			System.out.println("i "+i);
			if(i > 0) {
				flag = true;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
		
	}

}
