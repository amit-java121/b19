package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import model.Customer;

public class CustomerDao {
	
	public Customer fetchUserCredentialsFrmDB(String userEmail) {
		    Customer customer  = new Customer();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select customer_email,customer_password from login_tbl where customer_email='"+userEmail+"'");
			 
			while(rs.next()) {
				String username = rs.getString("customer_email");
				String password = rs.getString("customer_password");
				customer.setCustomerEmail(username);
				customer.setCustomerPassword(password);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return customer;
	}

}
