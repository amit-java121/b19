package service;

import dao.CustomerDao;
import model.Customer;

public class CustomerService {
	
	
	public boolean checkCustomerCredentials(String username,String password) {
		System.out.println("service layer called");
		//DB call
		 CustomerDao customerDao = new CustomerDao();
		 Customer customer = customerDao.fetchUserCredentialsFrmDB(username);
		 
		 if(customer != null && username != null && username.equalsIgnoreCase(customer.getCustomerEmail()) && password.equals(customer.getCustomerPassword())) {
			 return true;
		 }else {
			 return false;
		 }
		
		
	}
	
	
	public String saveCustomerDetails(Customer customer) {
		
		 CustomerDao customerDao = new CustomerDao();
		 String msg = customerDao.saveCustomerDetails(customer);
		 
		 return msg;
		
	}

}
