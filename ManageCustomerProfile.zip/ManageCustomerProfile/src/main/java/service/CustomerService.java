package service;

import java.util.List;

import dao.CustomerDao;
import model.Customer;

public class CustomerService {
	
	
	public boolean checkCustomerCredentials(String username,String password) {
		System.out.println("service layer called");
		//DB call
		 CustomerDao customerDao = new CustomerDao();
		 Customer customer = customerDao.fetchUserCredentialsFrmDB(username);
		 
		 if(customer != null && username != null && username.equalsIgnoreCase(customer.getCustomerEmail()) && password.equals(customer.getCustomerPassword())) {
			 return true;
		 }else {
			 return false;
		 }
		
		
	}
	
	
	public String saveCustomerDetails(Customer customer) {
		
		 CustomerDao customerDao = new CustomerDao();
		 String msg = customerDao.saveCustomerDetails(customer);
		 
		 return msg;
		
	}
	
	public List<Customer> getAllCustomersData(){
		 
		CustomerDao customerDao = new CustomerDao();
		 
		return customerDao.fetchAllCustomersData();
	}
	
	public boolean deleteCustomerById(int customerId) {
		CustomerDao customerDao = new CustomerDao();
		
		return customerDao.deleteCustomerById(customerId);
	}


	public Customer getCustomerById(int customerId) {
		
		CustomerDao customerDao = new CustomerDao();
		return customerDao.getCustomerById(customerId);
		
	}


	public boolean updateCustomer(Customer customer) {
		CustomerDao customerDao = new CustomerDao();
		return customerDao.updateCustomer(customer);
		
	}

}
