package service;

import dao.CustomerDao;
import model.Customer;

public class CustomerService {
	
	
	public boolean checkCustomerCredentials(String username,String password) {
		System.out.println("service layer called");
		//DB call
		 CustomerDao customerDao = new CustomerDao();
		 Customer customer = customerDao.fetchUserCredentialsFrmDB(username);
		 
		 if(username.equalsIgnoreCase(customer.getCustomerEmail()) && password.equals(customer.getCustomerPassword())) {
			 return true;
		 }else {
			 return false;
		 }
		
		
	}

}
