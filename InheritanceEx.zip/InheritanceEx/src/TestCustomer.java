
public class TestCustomer {
	
	
	public static void main(String[] args) {
	
		PrepareData pd = new PrepareData();
		Customer customer = pd.setCustomerData();
		
		System.out.println(customer.toString());
		
//		System.out.println(customer.getCustomerId());
//		System.out.println(customer.getCustomerName());
//		System.out.println(customer.getCustomerGender());
//		System.out.println(customer.getFlatNumber());
//		System.out.println(customer.getSocietyName());
		
	}

}
