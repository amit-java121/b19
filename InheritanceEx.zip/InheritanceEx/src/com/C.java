package com;

public class C extends B {
	
	int a = 100;
	
	public void m3() {
		System.out.println("m3 called from class C");
		
		System.out.println(mobileNumber);
		m1();
	}
	
	
	public static void main(String[] args) {
		
		C c = new C();
		
	}

}
