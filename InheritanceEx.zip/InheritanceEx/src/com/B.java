package com;

public class B extends A{
	
	int mobileNumber = 98292882;
	
	public void m2(int num) {
		System.out.println("m2 called from class B"+num);
	}
	
	public void test() {
	
		System.out.println(age);
		System.out.println(mobileNumber);
		
		int num = m1();
		
		m2(num);
		
	}
	
	
	
	public static void main(String[] args) {
		
		//A a = new A();
		
	   B b = new B();
		b.test();
	
	}

}
