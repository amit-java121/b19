package com;

public class A {
	
	int age = 30;
	
	public int m1() {
		System.out.println("m1 called from class A");
		
		return 1000;
	}

}
