package hierarchical;

public class C extends A{
	
	

}
