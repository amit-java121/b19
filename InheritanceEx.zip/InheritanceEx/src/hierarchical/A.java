package hierarchical;

public class A {
	
	int a = 200;
	
	void m1() {
		System.out.println("m1 called::");
	}

}
