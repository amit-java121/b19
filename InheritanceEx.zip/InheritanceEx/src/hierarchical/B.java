package hierarchical;

public class B extends A{
	
	int b = 300;
	
	void m2() {
		System.out.println("m2 called::");
	}

}
