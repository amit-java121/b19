
public class PrepareData {
	
	public Customer setCustomerData() {
		
		Customer customer = new Customer();
		
		customer.setCustomerId(1001);
		customer.setCustomerName("Ajay");
		customer.setCustomerGender("male");
		customer.setContactNumber(191919919);
		customer.setFlatNumber("B 503");
		customer.setSocietyName("Annexe");
		customer.setCityName("Pune");
		customer.setState("MH");
		customer.setCountry("India");
		
		return customer;
		
	}

}
