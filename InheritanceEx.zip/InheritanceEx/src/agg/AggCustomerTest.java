package agg;

public class AggCustomerTest {
	
	public Customer prepareCustomerData() {
		
		Customer customer = new Customer();
		
		customer.setCustomerId(1002);
		customer.setCustomerName("Bijay");
		customer.setContactNumber(989819199);
		customer.setCustomerGender("male");
		
		Address add = new Address();
		
		add.setFlatNumber("B 504");
		add.setSocietyName("magarpatta");
		add.setCityName("pune");
		add.setState("MH");
		add.setCountry("india");
		
		customer.setAddress(add);
		
		return customer;
	}
	
	
	
	public void printCustomerData() {

		Customer cust = prepareCustomerData();
		
		int id = cust.getCustomerId();
		String country = cust.getAddress().getCountry();
		
		System.out.println("id "+id);
		System.out.println("country name "+country);
		//System.out.println(cust.toString());
	
	}
	
	public static void main(String[] args) {
		AggCustomerTest act = new AggCustomerTest();
		act.printCustomerData();
	}

}
