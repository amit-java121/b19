package agg;

public class Address {
	
	private String flatNumber;
	private String societyName;
	private String cityName;
	private String state;
	private String country;
	
	public String getFlatNumber() {
		return flatNumber;
	}
	public void setFlatNumber(String flatNumber) {
		this.flatNumber = flatNumber;
	}
	public String getSocietyName() {
		return societyName;
	}
	public void setSocietyName(String societyName) {
		this.societyName = societyName;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	@Override
	public String toString() {
		return "Address [flatNumber=" + flatNumber + ", societyName=" + societyName + ", cityName=" + cityName
				+ ", state=" + state + ", country=" + country + "]";
	}
	
	

}
