package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeSerilizationTest {
	
	public static void main(String[] args) {
		
	
		try {
		
		File file = new File("C:\\Users\\Amit\\Desktop\\Test.txt");
		
		FileInputStream fis = new FileInputStream(file);
		
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		//Payment payment = (Payment)ois.readObject();

		Customer customer = (Customer)ois.readObject();
		
		System.out.println("customer id:"+customer.getCustomerId());
		System.out.println("customer name: "+customer.getCustomerName());
		System.out.println("card number:: "+customer.getCardNumber());
		System.out.println("cvv "+customer.getCvvNo());
		
		ois.close();
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
