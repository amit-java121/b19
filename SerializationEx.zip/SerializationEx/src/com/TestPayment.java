package com;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class TestPayment {
	
	public static void main(String[] args) {
		
//		Payment payment = new Payment();
//		
//		payment.setCardNumber(8282828882l);
//		payment.setCustomerId(1001);
//		payment.setCustomerName("Harish");
//		payment.setCvvNo(1234);
		
		Customer customer = new Customer();
		customer.setCardNumber(8282828882l);
		customer.setCustomerId(1001);
		customer.setCustomerName("Harish");
		customer.setCvvNo(1234);
		
		try {
		File file = new File("C:\\Users\\Amit\\Desktop\\Test.txt");
		
		FileOutputStream fos = new FileOutputStream(file);
		
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(customer);
		
		oos.close();
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
