package com;

import java.io.Serializable;

public class Payment{
	private long cardNumber;
	private int cvvNo;
	
	public long getCardNumber() {
		return cardNumber;
	}
	public int getCvvNo() {
		return cvvNo;
	}
	
	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}
	public void setCvvNo(int cvvNo) {
		this.cvvNo = cvvNo;
	}

	

}
