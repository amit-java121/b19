package com;

public class Bus implements Vehicle {

	@Override
	public int engine(String modelName) {
		if(modelName.equals("tata")) {
			return 2500;
		}
		
		return 0;
	}

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String colors() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String axleDimention() {
		// TODO Auto-generated method stub
		return null;
	}

}
