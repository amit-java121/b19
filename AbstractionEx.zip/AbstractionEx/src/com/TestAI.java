package com;

public class TestAI implements IA {

	@Override
	public void add(int a, int b) {
		
		System.out.println(a+b);
		
	}

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}
	
	
	public static void main(String[] args) {
		TestAI ta = new TestAI();
		ta.add(10, 10);
	}

}
