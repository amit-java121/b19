package com;

public interface Vehicle {
	int engine(String modelName);
	int weels();
	String colors();
	String axleDimention();

}
