package com;

public interface IA {
	
	void add(int a,int b);
	
	void m1();

}
