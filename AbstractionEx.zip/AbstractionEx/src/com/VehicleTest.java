package com;

public class VehicleTest {
	
	public static void main(String[] args) {
		
		Bike bike = new Bike();
		int engineHP = bike.engine("pulsar-100");
		System.out.println(engineHP);
		
		System.out.println(bike.colors());
		
	}

}
