package com;

public class Bike implements Vehicle{

	@Override
	public int engine(String modelName) {
		
		if(modelName.equals("pulsar-150")) {
		 return 150;	
		}else {
			return 0;
		}
		
	}

	@Override
	public int weels() {

		
		return 2;
	}

	@Override
	public String colors() {
		
		return "blue";
	}

	@Override
	public String axleDimention() {
		// TODO Auto-generated method stub
		return null;
	}

}
