package cont;

public class B {
	
	public B() {
		this(100);
		System.out.println("default const:::");
		m1();
		
	}
	
	public B(int number) {
		this(1000,"hello");
		System.out.println("param 1 const:::");
	}
	
	public B(int number,String str) {
		System.out.println("param 2 const:::");
	}
	
	
	void m1() {
		System.out.println("m1 called::");
	}
	
	void m2() {
		System.out.println("m2 called::");
	}
	
	
	public static void main(String[] args) {
		
		B b = new B();
		System.out.println("");
		b.m2();
		
	}

}
