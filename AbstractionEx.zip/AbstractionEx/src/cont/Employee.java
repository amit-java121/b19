package cont;

public class Employee {
	private int empId;
	private String empName;
	private int age;
	private String empAddress;
	
	
	public Employee(int empId,String empName,int age,String empAddress) {
		this.empId = empId;
		this.empName = empName;
		this.age = age;
		this.empAddress = empAddress; 
	}
	
	public void printEmpData() {
		System.out.println(empId);
		System.out.println(empName);
		System.out.println(age);
		System.out.println(empAddress);
	}
	
	public static void main(String[] args) {
		Employee emp1 = new Employee(100,"Ajay",25,"pune");
		Employee emp2 = new Employee(101,"Bjay",25,"mumbai");
		Employee emp3 = new Employee(102,"Sanjay",25,"nagpur");
		
		emp1.printEmpData();
		emp2.printEmpData();
		emp3.printEmpData();
		
	}

}
