package cont;

public class A {
	
	
	int age;
	
	public A() {
		System.out.println("default const:::"+age);
	}
	
	public A(int age) {
		this.age = age;
		System.out.println("default const:::"+age);
	}
	
	
	void m1() {
		System.out.println(age);
	}
	
	
	
	
	
	public static void main(String[] args) {
		//A aaa = new A();
		
		A a = new A(30);
		
		a.m1();
	}
	

}
