package cont;

public class StaticBlockEx {
	
	int num;
	static int num2;
	
	{
		System.out.println("init block");
		num = 123;
	}
	
	public StaticBlockEx() {
		num = 100;
		
		System.out.println("const called:::");
	}
	
	static {
		System.out.println("static block called::");
		num2 = 1000;
		
	}
	
	public void print() {
		System.out.println(num);
		System.out.println(num2);
	}

	
	public static void main(String[] args) {
		StaticBlockEx sb = new StaticBlockEx();
		//sb.print();
	}
	
	

}
