package abst;

public abstract class CommonLogic {
	
	public boolean validateUserCredentilas(String username, String password) {
		
		//
		String userNameFrmDB = "ajay@gmail.com";
		String passwordFrmDB = "ajay@123";
		
		if(username.equals(userNameFrmDB) && password.equals(passwordFrmDB)) {
			return true;
		}else {
			return false;
		}
		
		
	}
	
	
	public abstract void logUserActivities(String username,String desc);

}
