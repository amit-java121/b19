package abst;

public class TestPayment {
	
	public static void main(String[] args) {
		
		Payment payment = new Payment();
		
		payment.doPayment(1000, "ajay@gmail.com", "ajay@123");
		
	}

}
