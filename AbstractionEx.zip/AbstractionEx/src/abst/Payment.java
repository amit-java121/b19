package abst;

public class Payment extends CommonLogic{
	
	
	public void doPayment(int amt,String username,String password) {
		
		//validate user 
		Payment payment =  new Payment();
		boolean isUserValid = payment.validateUserCredentilas(username, password);
		
		if(isUserValid) {
			// withdraw logic
			System.out.println("requested amount has been transffered successfylly!!!");
			logUserActivities(username,"Payment done");
			
		}else {
			System.out.println("user is not valid!!");
			logUserActivities(username,"Payment not done due to user is invalid");
		}
		
		
		
		
	}

	
	@Override
	public void logUserActivities(String username,String desc) {
	
		System.out.println("record the payment steps into file "+username+" reason "+desc);
	}
	

}
