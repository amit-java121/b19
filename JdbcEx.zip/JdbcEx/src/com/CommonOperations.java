package com;

import java.util.ArrayList;
import java.util.List;

public class CommonOperations {
	
	public void fetchCustomerRecord() {
		ConnectionProvider cp  = new ConnectionProvider();
		ArrayList<Customer> listOfCustomers = cp.fetchAllCustomerData();
		
		System.out.println(listOfCustomers.toString());
	}
	
	public void insertCustomerrecord() {
		Customer customer = new Customer();
		customer.setCustomerName("Ajay");
		customer.setAddress("mumbai");
		customer.setContactNumber(98989898);
		customer.setCountryName("Italy");
		customer.setGender("male");
	
		ConnectionProvider cp  = new ConnectionProvider();
		cp.saveCustomerRecord(customer);
		
	}
	
	public void deleteCustomerById() {
		
//		Customer c = new Customer();
//		c.setCustomerId(2);
		
		ConnectionProvider cp  = new ConnectionProvider();
		cp.deleteCustomerById(2);
	}
	
	public void updateCustomerData() {
		
		Customer customer = new Customer();
		customer.setCustomerId(3);
		customer.setAddress("mumbai");
		customer.setContactNumber(111212121);
	
		
		ConnectionProvider cp  = new ConnectionProvider();
		cp.updateCustomerRecord(customer);
	}
	
	public void insertCustomerByPreparedStmt() {
		Customer customer = new Customer();
		customer.setCustomerName("Ajay");
		customer.setAddress("mumbai");
		customer.setContactNumber(98989898);
		customer.setCountryName("Italy");
		customer.setGender("male");
		
		ConnectionProvider cp  = new ConnectionProvider();
		cp.insertCustomerData(customer);
		
	}
	
	//save multiple records
	
	public void saveListOfCustomerRecords() {
		
		Customer customer = new Customer();
		customer.setCustomerName("Ajay");
		customer.setAddress("mumbai");
		customer.setContactNumber(98989898);
		customer.setCountryName("Italy");
		customer.setGender("male");
		
		Customer customer2 = new Customer();
		customer2.setCustomerName("Harish");
		customer2.setAddress("nagpur");
		customer2.setContactNumber(98989118);
		customer2.setCountryName("Italy");
		customer2.setGender("male");
		
		Customer customer3 = new Customer();
		customer3.setCustomerName("Tushar");
		customer3.setAddress("pune");
		customer3.setContactNumber(98989118);
		customer3.setCountryName("Italy");
		customer3.setGender("male");
		
		List<Customer> listOfCustomers = new ArrayList<>();
		listOfCustomers.add(customer);
		listOfCustomers.add(customer2);
		listOfCustomers.add(customer3);
		
		ConnectionProvider cp  = new ConnectionProvider();
		cp.insertListOfCustomers(listOfCustomers);
		
	}
	
	
	public static void main(String[] args) {
	
		CommonOperations co = new CommonOperations();
		//co.fetchCustomerRecord();
		//co.insertCustomerrecord();
		//co.deleteCustomerById();
		//co.updateCustomerData();
		//co.insertCustomerByPreparedStmt();
		//co.saveListOfCustomerRecords();
		
		ConnectionProvider.getImage(9);
	}

}
