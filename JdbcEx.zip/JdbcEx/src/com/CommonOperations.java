package com;

import java.util.ArrayList;

public class CommonOperations {
	
	public void fetchCustomerRecord() {
		ConnectionProvider cp  = new ConnectionProvider();
		ArrayList<Customer> listOfCustomers = cp.fetchAllCustomerData();
		
		System.out.println(listOfCustomers.toString());
	}
	
	public void insertCustomerrecord() {
		Customer customer = new Customer();
		customer.setCustomerName("Ajay");
		customer.setAddress("mumbai");
		customer.setContactNumber(98989898);
		customer.setCountryName("Italy");
		customer.setGender("male");
	
		ConnectionProvider cp  = new ConnectionProvider();
		cp.saveCustomerRecord(customer);
		
	}
	
	
	public static void main(String[] args) {
	
		CommonOperations co = new CommonOperations();
		co.fetchCustomerRecord();
		//co.insertCustomerrecord();
	}

}
