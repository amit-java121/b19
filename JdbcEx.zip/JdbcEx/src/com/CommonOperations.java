package com;

import java.util.ArrayList;

public class CommonOperations {
	
	public void fetchCustomerRecord() {
		ConnectionProvider cp  = new ConnectionProvider();
		ArrayList<Customer> listOfCustomers = cp.fetchAllCustomerData();
		
		System.out.println(listOfCustomers.toString());
	}
	
	public void insertCustomerrecord() {
		Customer customer = new Customer();
		customer.setCustomerName("Ajay");
		customer.setAddress("mumbai");
		customer.setContactNumber(98989898);
		customer.setCountryName("Italy");
		customer.setGender("male");
	
		ConnectionProvider cp  = new ConnectionProvider();
		cp.saveCustomerRecord(customer);
		
	}
	
	public void deleteCustomerById() {
		
//		Customer c = new Customer();
//		c.setCustomerId(2);
		
		ConnectionProvider cp  = new ConnectionProvider();
		cp.deleteCustomerById(2);
	}
	
	public void updateCustomerData() {
		
		Customer customer = new Customer();
		customer.setCustomerId(3);
		customer.setAddress("mumbai");
		customer.setContactNumber(111212121);
	
		
		ConnectionProvider cp  = new ConnectionProvider();
		cp.updateCustomerRecord(customer);
	}
	
	public void insertCustomerByPreparedStmt() {
		Customer customer = new Customer();
		customer.setCustomerName("Ajay");
		customer.setAddress("mumbai");
		customer.setContactNumber(98989898);
		customer.setCountryName("Italy");
		customer.setGender("male");
		
		ConnectionProvider cp  = new ConnectionProvider();
		cp.insertCustomerData(customer);
		
	}
	
	public static void main(String[] args) {
	
		CommonOperations co = new CommonOperations();
		//co.fetchCustomerRecord();
		//co.insertCustomerrecord();
		//co.deleteCustomerById();
		//co.updateCustomerData();
		co.insertCustomerByPreparedStmt();
	}

}
