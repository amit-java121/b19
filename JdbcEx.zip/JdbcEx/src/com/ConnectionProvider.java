package com;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ConnectionProvider {
	
	public static Statement getConnection() {
		Statement stmt = null;
		try {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
		  stmt = conn.createStatement();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return stmt;
	}
	
	
	public ArrayList<Customer> fetchAllCustomerData() {
		 ArrayList<Customer> customerList = new ArrayList<Customer>();
		try {
		//Statement stmt = getConnection();
		 ResultSet rs = getConnection().executeQuery("select * from customer");
		
		 while(rs.next()) {
			 Customer customer = new Customer();
			 
			 customer.setCustomerId(rs.getInt("customer_id"));
			 customer.setCustomerName(rs.getString("customer_name"));
			 customer.setAddress(rs.getString("coustmer_address"));
			 customer.setContactNumber(rs.getInt("customer_contact_no"));
			 customer.setCountryName(rs.getString("customer_country"));
			 customer.setGender(rs.getString("customer_gender"));
			 
			 customerList.add(customer);
			 
		 }
		 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return customerList;
		}
	
	
	public void saveCustomerRecord(Customer customer) {
	
		try {
		
			 int i = getConnection().executeUpdate("insert into customer (customer_name,coustmer_address,customer_contact_no,customer_country,customer_gender) "
			 		+ "values('"+customer.getCustomerName()+"','"+customer.getAddress()+"',"+customer.getContactNumber()+",'"+customer.getCountryName()+"','"+customer.getGender()+"')");
			 
			 System.out.println("i ="+i);
			 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void deleteCustomerById(int id) {
		
		try {
			 
			 int i = getConnection().executeUpdate("delete from customer where customer_id="+id+"");
			 
			 System.out.println("i ="+i);
			 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void updateCustomerRecord(Customer customer) {
		
		try {
			 int i = getConnection().executeUpdate("update customer set customer_contact_no='"+customer.getContactNumber()+"',coustmer_address='"+customer.getAddress()+"' where customer_id="+customer.getCustomerId()+"");
			 System.out.println("i ="+i);
			 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	//using prepared statment
	
	public void insertCustomerData(Customer customer) {
		
		try {
		
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
			
			PreparedStatement pstmt = conn.prepareStatement("insert into customer (customer_name,coustmer_address,customer_contact_no,customer_country,customer_gender,image_name,image) values(?,?,?,?,?,?,?) ");
			
			pstmt.setString(1, customer.getCustomerName());
			pstmt.setString(2, customer.getAddress());
			pstmt.setInt(3, customer.getContactNumber());
			pstmt.setString(4, customer.getCountryName());
			pstmt.setString(5, customer.getGender());
			pstmt.setString(6, "photo");
			
			FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\photo.jpg");
			pstmt.setBinaryStream(7, fis,fis.available());
			
			int i= pstmt.executeUpdate();
			
			 System.out.println("i ="+i);
			 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void insertListOfCustomers(List<Customer> listOfCustomers) {
			
			try {
			
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
				
				PreparedStatement pstmt = conn.prepareStatement("insert into customer (customer_name,coustmer_address,customer_contact_no,customer_country,customer_gender) values(?,?,?,?,?) ");
				
				
				for(Customer customer:listOfCustomers) {
					
				pstmt.setString(1, customer.getCustomerName());
				pstmt.setString(2, customer.getAddress());
				pstmt.setInt(3, customer.getContactNumber());
				pstmt.setString(4, customer.getCountryName());
				pstmt.setString(5, customer.getGender());
				
				int i= pstmt.executeUpdate();
				 System.out.println("i ="+i);
				}
				 
			}catch(Exception e) {
				e.printStackTrace();
			}
			
		}
	
	
	public static void getImage(int customerId) {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
		
		PreparedStatement pstmt = conn.prepareStatement("select image_name,image from customer where customer_id="+customerId+"");
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next()) {
			System.out.println(rs.getString("image_name"));
			Blob bb =rs.getBlob("image");
			byte ba[] = bb.getBytes(1, (int)bb.length());
			
			FileOutputStream fos = new FileOutputStream("C:\\Users\\Amit\\Desktop\\test\\test.jpg");
			fos.write(ba);
			fos.close();
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
