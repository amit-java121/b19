package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ConnectionProvider {
	
	public ArrayList<Customer> fetchAllCustomerData() {
		 ArrayList<Customer> customerList = new ArrayList<Customer>();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
		 Statement stmt = conn.createStatement();
		 ResultSet rs = stmt.executeQuery("select * from customer");
		
		 while(rs.next()) {
			 Customer customer = new Customer();
			 
			 customer.setCustomerId(rs.getInt("customer_id"));
			 customer.setCustomerName(rs.getString("customer_name"));
			 customer.setAddress(rs.getString("coustmer_address"));
			 customer.setContactNumber(rs.getInt("customer_contact_no"));
			 customer.setCountryName(rs.getString("customer_country"));
			 customer.setGender(rs.getString("customer_gender"));
			 
			 customerList.add(customer);
			 
		 }
		 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return customerList;
		}
	
	
	public void saveCustomerRecord(Customer customer) {
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
			 Statement stmt = conn.createStatement();
			 
			 
			 int i = stmt.executeUpdate("insert into customer (customer_name,coustmer_address,customer_contact_no,customer_country,customer_gender) "
			 		+ "values('"+customer.getCustomerName()+"','"+customer.getAddress()+"',"+customer.getContactNumber()+",'"+customer.getCountryName()+"','"+customer.getGender()+"')");
			 
			 System.out.println("i ="+i);
			 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
