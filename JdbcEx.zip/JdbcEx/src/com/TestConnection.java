package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestConnection {
	
	public void testConnection() {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","root");
		 System.out.println("step 2");
		 Statement stmt = conn.createStatement();
		 ResultSet rs = stmt.executeQuery("select * from customer");
		 System.out.println("step 3");
		 while(rs.next()) {
			 System.out.println(rs.getInt("customer_id"));
			 System.out.println(rs.getString("customer_name"));
			 System.out.println(rs.getInt("customer_contact_no"));
			 System.out.println(rs.getString("coustmer_address"));
			 System.out.println(rs.getString("customer_country"));
			 System.out.println(rs.getString("customer_gender"));
		 }
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	public static void main(String[] args) {
		
		TestConnection tc = new TestConnection();
		tc.testConnection();
	
	}

}
