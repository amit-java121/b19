package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.model.User;
import com.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@GetMapping("/login")
	public String login(@RequestParam("username") String username,@RequestParam("password") String password) {
		
		System.out.println("user name"+username+" password "+password);
		
		boolean flag = userService.verifyUserCredentials(username,password);
		if(flag) {
			return "You are logged in successfully!!!!";
		}
		
		return "Your user name and password is incorrect please try again!!";
	}
	
	@PostMapping("/save")
	public User saveUser(@RequestBody User user ) {
		
		 User user1 = userService.saveUserRecord(user);
		
		return user1;
	}
	
	@GetMapping("/getAllUsers")
	public List<User> getAllUsers(){
		
		List<User> listOfUsers = userService.getAllUsers();
		
		return listOfUsers;
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteUserById(@PathVariable("id") int id) {
		System.out.println("id "+id);
		boolean flag = userService.deleteUserById(id);
		
		if(flag) {
		return new ResponseEntity<String>("User deleted successfully!!!", HttpStatus.OK);	
		}
		
	
		return new ResponseEntity<String>("User could not delete due to some issue!!!", HttpStatus.BAD_REQUEST);
	}
	
	//@PutMapping("/update")
	@PatchMapping("/update")
	public void updateUser(@RequestBody User user) {
		
		userService.updateUserById(user);
		
	}

}
