package com.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{

	User getByCustomerEmail(String username);

	@Modifying
	@Query("update User u set u.customerName=:customername,u.contactNumber=:contactNo where u.customerId=:id")
	void updateUserById(@Param("customername") String customerName,@Param("contactNo") long contactNo,@Param("id") int id);

}
