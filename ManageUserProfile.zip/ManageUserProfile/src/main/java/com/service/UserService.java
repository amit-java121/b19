package com.service;

import com.model.User;

public interface UserService {

	boolean verifyUserCredentials(String username, String password);

	void saveUserRecord(User user);

}
