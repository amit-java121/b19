package com.service;

import java.util.List;

import com.model.User;

public interface UserService {

	boolean verifyUserCredentials(String username, String password);

	User saveUserRecord(User user);

	List<User> getAllUsers();

	boolean deleteUserById(int id);

	void updateUserById(User user);

}
