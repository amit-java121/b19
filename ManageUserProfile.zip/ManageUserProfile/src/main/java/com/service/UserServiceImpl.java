package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.UserRepository;
import com.model.User;

@Service
@Transactional
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository userRepository;

	@Override
	public boolean verifyUserCredentials(String username, String password) {
	
		
		User user = userRepository.getByCustomerEmail(username);
		
		if(user != null && user.getCustomerPassword().equals(password)) {
			return true;
		}
		
		return false;
		
	}

	@Override
	public User saveUserRecord(User user) {
		
		User user1 = userRepository.save(user);
		System.out.println("save method::"+user1.toString());
		
		return user1;
	}

	@Override
	public List<User> getAllUsers() {
		
		//List<User> listOfUsers = userRepository.findAll();
		
		return userRepository.findAll();
	}

	@Override
	public boolean deleteUserById(int id) {
		try {
			userRepository.deleteById(id);
			return true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public void updateUserById(User user) {
		
		//userRepository.save(user);
		
		userRepository.updateUserById(user.getCustomerName(),user.getContactNumber(),user.getCustomerId());
		
	}

}
