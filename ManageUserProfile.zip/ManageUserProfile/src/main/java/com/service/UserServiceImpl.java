package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserRepository;
import com.model.User;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository userRepository;

	@Override
	public boolean verifyUserCredentials(String username, String password) {
	
		
		User user = userRepository.getByCustomerEmail(username);
		
		if(user != null && user.getCustomerPassword().equals(password)) {
			return true;
		}
		
		return false;
		
	}

	@Override
	public void saveUserRecord(User user) {
		
		userRepository.save(user);
	}

}
