package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestCheckedException {
	
	public void createDataBase() {
		Connection con = null;
		//MYSQL-->Microsoft
		//ORACLE-->Oracle
		//DB2--> cybase
		//jdbc --jar
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		 con = DriverManager.getConnection("");
		
		}catch(Exception e) {
			System.out.println(e);
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
	public void readDataFromFile() throws FileNotFoundException {
		//try {
		File file = new File("c://test.txt");
		
		FileInputStream fis = new FileInputStream(file);
		
//		}catch(Exception e) {
//			System.out.println(e);
//		}
	}
	
	
	public static void main(String[] args) {
		TestCheckedException tce = new TestCheckedException();
		try {
		tce.readDataFromFile();
		}catch(Exception e) {
			
		}
	}

}
