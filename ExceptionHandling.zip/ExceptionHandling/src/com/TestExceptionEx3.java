package com;

public class TestExceptionEx3 {
	
	public void division(int a,int b) {
		
		try {
		
		int result = a/b;
		System.out.println(result);
		
		}catch(ArithmeticException ae) {
			System.out.println("catch block executed:::"+ae);
		
			
		}finally {
			System.out.println("finally block executed and connection is closed::");
			//close connection
		}
		
	}
	
	public static void main(String[] args) {
		TestExceptionEx3 tee = new TestExceptionEx3();
		tee.division(10, 0);
	}

}
