package com;

public class TestExceptionEx4 {
	
	public void division(int a,int b) {
		
		try {
		
		int result = a/b;
		System.out.println(result);
		
		}finally {
			System.out.println("finally block executed and connection is closed::");
			//close connection
		}
		
	}
	
	public static void main(String[] args) {
		TestExceptionEx4 tee = new TestExceptionEx4();
		tee.division(10, 0);
	}

}
