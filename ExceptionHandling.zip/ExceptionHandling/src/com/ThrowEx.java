package com;

public class ThrowEx {
	
	public void test(int number) {
		
		if(number > 0) {
			System.out.println("write some logic");
		}else {
			throw new IllegalArgumentException("given number should not be zero::");
		}
		
		
	}
	
	public static void main(String[] args) {
		ThrowEx te = new ThrowEx();
		try {
		te.test(0);
		}catch(Exception e) {
			System.out.println("catch block executed:: "+e);
		}
	}

}
