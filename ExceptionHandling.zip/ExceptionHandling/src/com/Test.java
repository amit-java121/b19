package com;

public class Test {
	
	public void calculation(int a,int b,String userName) {
		System.out.println("stmt 1");
		System.out.println("stmt 2");
		System.out.println("stmt 3");
		try {
			int result = a/b;//suspected
			System.out.println("result:: "+result);
			
			if(userName.equals("ajay")) {
				System.out.println("if condition executed::");
			}
			
		}catch(ArithmeticException ae) {
			System.out.println("catch block executed "+ae);
		}catch(NullPointerException npe) {
			System.out.println("npe catch block executed::");
		}
		
		System.out.println("stmt 4");
		System.out.println("stmt 5");
		System.out.println("stmt 6");
		
	}
	
	public static void main(String[] args) {
		Test test = new Test();
		test.calculation(10, 2,null);
	}

}
