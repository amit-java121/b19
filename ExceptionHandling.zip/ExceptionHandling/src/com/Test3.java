package com;

public class Test3 {
	
	public void calculation(int a,int b,String userName) {
		System.out.println("stmt 1");
		System.out.println("stmt 2");
		System.out.println("stmt 3");
		try {
			int result = a/b;//suspected
			System.out.println("result:: "+result);
			
			if(userName.equals("ajay")) {
				System.out.println("if condition executed::");
			}
			//some code 
			
		}catch(ArithmeticException ae) {
			System.out.println("catch block executed "+ae);
		}catch(NullPointerException npe) {
			System.out.println("npe catch block executed::");
		}catch(Exception e) {
			System.out.println("exception "+e);
		}
		
		System.out.println("stmt 4");
		System.out.println("stmt 5");
		System.out.println("stmt 6");
		
	}
	
	public static void main(String[] args) {
		Test3 test = new Test3();
		test.calculation(10, 2,null);
	}

}
