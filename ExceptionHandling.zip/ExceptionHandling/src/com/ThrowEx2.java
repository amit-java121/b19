package com;

public class ThrowEx2 {
	
	public void test(int number) throws IllegalArgumentException{
		
		if(number > 0) {
			System.out.println("write some logic");
		}else {
			throw new IllegalArgumentException("given number should not be zero::");
			//throw new Exception("number should not be zero!!!");
		}
		
		
	}
	
	public static void main(String[] args) {
		ThrowEx2 te = new ThrowEx2();
		try {
		te.test(0);
		}catch(Exception e) {
			System.out.println("catch block executed:: "+e);
		}
	}

}
