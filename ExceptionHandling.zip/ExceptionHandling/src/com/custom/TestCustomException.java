package com.custom;

public class TestCustomException {
	
	public boolean validateUser(String userName,String userpass) {
		
		if(userName.equals("xpertit") && userpass.equals("xpertit")) {
			return true;
		}else {
			
			return false;
		}
		
		
	}
	
	public boolean processUserData(String request) throws ServerError {
		
		//network issue
		
		if(request.equals("networkissue")) {
			
			throw new ServerError(500,"server is down");
			
		}else {
			return validateUser("xpertit","xpertit");
		}
		
	}

}
