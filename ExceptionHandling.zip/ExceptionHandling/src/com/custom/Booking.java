package com.custom;

public class Booking {
	
	public void processPaymnet() {
		//
		TestCustomException tce = new TestCustomException();
		
		try {
			boolean flag = tce.processUserData("networkissue");
			if(flag) {
				System.out.println("you are logged in:::");
			}
		} catch (ServerError e) {
			System.out.println(e.getErrorCode());
			System.out.println(e.getErrorDesc());
		}
		
	}
	
	public static void main(String[] args) {
		Booking b = new Booking();
		b.processPaymnet();
	}

}
