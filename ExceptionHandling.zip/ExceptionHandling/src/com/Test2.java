package com;

public class Test2 {
	
	public void calculation(int a,int b,String userName) {
		System.out.println("stmt 1");
		System.out.println("stmt 2");
		System.out.println("stmt 3");
		try {
			int result = a/b;//suspected
			System.out.println("result:: "+result);
			
		}catch(Exception e) {
			System.out.println("catch block executed::"+e);
		}
		
		try {
			
			if(userName.equals("ajay")) {
				System.out.println("if condition executed::");
			}
		}catch(Exception e) {
			System.out.println("catch of nullpinter executed");
		}
		
		System.out.println("stmt 4");
		System.out.println("stmt 5");
		System.out.println("stmt 6");
		
	}
	
	public static void main(String[] args) {
		Test2 test = new Test2();
		test.calculation(10, 0,"ajay");
	}

}
