package map;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapEx {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> hashMap = new HashMap<>();
		
		hashMap.put(100, "ajay");
		hashMap.put(101, "bijay");
		hashMap.put(102, "sanjay");
		//hashMap.put(100, "ajay123");
		
//		for(Entry<Integer, String> map:hashMap.entrySet()) {
//			System.out.println(map.getKey()+" "+map.getValue());
//		}
		
//		

		
//		hashMap.putIfAbsent(103, "test");
//		
//		System.out.println(hashMap);
		
//		String value = hashMap.getOrDefault(103, "testtest");
//		System.out.println(value);
		
//		Set<Integer> keys = hashMap.keySet();
//		System.out.println(keys);
		
//		Collection<String> values = hashMap.values();
//		System.out.println(values);
		
		List<String> values = (List)hashMap.values();
		System.out.println(values);
		
//		List<String> list  = new ArrayList<>();
//		List<String> linkedList = new LinkedList<>();
//		
//		ArrayList<String> listt = new ArrayList<>();
		
		System.out.println(hashMap.size());
		
		
	}

}
