package map;

import java.util.LinkedHashMap;

public class LinkedHashMapEx {
	
	public static void main(String[] args) {
		LinkedHashMap<Integer, String> linkedHashMap = new LinkedHashMap<>();
		
	}

}
