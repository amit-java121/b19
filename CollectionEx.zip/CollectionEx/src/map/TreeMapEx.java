package map;

import java.util.SortedMap;
import java.util.TreeMap;

public class TreeMapEx {
	
	public static void main(String[] args) {
//		TreeMap<Integer, String> treeMap = new TreeMap<>();
//		treeMap.put(104, "ajay");
//		treeMap.put(102, "sanjay");
//		treeMap.put(101, "Bijay");
//		treeMap.put(106, "xpertit");
//		treeMap.put(107, null);
//		
//		System.out.println(treeMap);
		
		
		TreeMap<String, String> treeMap = new TreeMap<>();
		treeMap.put("key1", "ajay");
		treeMap.put("key5", "sanjay");
		treeMap.put("key4", "Bijay");
		treeMap.put("key3", "xpertit");
		treeMap.put("key2", null);
		
		System.out.println(treeMap);
		
		SortedMap<String, String> treeMap2 = treeMap.subMap("key1", "key4");
		System.out.println(treeMap2);
	}

}
