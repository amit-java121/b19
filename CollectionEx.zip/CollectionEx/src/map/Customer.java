package map;

public class Customer {
	private int customerAddhar;
	private String customerName;
	private String customerGender;
	private String customerAddress;
	private long customerContactNo;
	public int getCustomerAddhar() {
		return customerAddhar;
	}
	public String getCustomerName() {
		return customerName;
	}
	public String getCustomerGender() {
		return customerGender;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public long getCustomerContactNo() {
		return customerContactNo;
	}
	public void setCustomerAddhar(int customerAddhar) {
		this.customerAddhar = customerAddhar;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public void setCustomerContactNo(long customerContactNo) {
		this.customerContactNo = customerContactNo;
	}
	
	
	@Override
	public String toString() {
		return "Customer [customerAddhar=" + customerAddhar + ", customerName=" + customerName + ", customerGender="
				+ customerGender + ", customerAddress=" + customerAddress + ", customerContactNo=" + customerContactNo
				+ "]";
	}
	

}
