package map;

import java.util.HashMap;

public class PrepareData {
	
	public HashMap<Integer, Customer> prepareCustomerData() {
		
		Customer customer = new Customer();
		customer.setCustomerAddhar(101010001);
		customer.setCustomerName("Ajay singh");
		customer.setCustomerContactNo(908188181l);
		customer.setCustomerGender("male");
		customer.setCustomerAddress("pune");
		
		Customer customer2 = new Customer();
		customer2.setCustomerAddhar(101010002);
		customer2.setCustomerName("Bijay singh");
		customer2.setCustomerContactNo(908188181l);
		customer2.setCustomerGender("male");
		customer2.setCustomerAddress("mumbai");
		
		Customer customer3 = new Customer();
		customer3.setCustomerAddhar(101010003);
		customer3.setCustomerName("Pavan");
		customer3.setCustomerContactNo(908188181l);
		customer3.setCustomerGender("male");
		customer3.setCustomerAddress("nagpur");
		
		HashMap<Integer, Customer> customerMap = new HashMap<>();
		customerMap.put(customer.getCustomerAddhar(), customer);
		customerMap.put(customer2.getCustomerAddhar(), customer2);
		customerMap.put(customer3.getCustomerAddhar(), customer3);
		
		return customerMap;
	}

}
