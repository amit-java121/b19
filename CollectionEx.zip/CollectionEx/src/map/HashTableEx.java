package map;

import java.util.Hashtable;

public class HashTableEx {
	
	public static void main(String[] args) {
		
		Hashtable<Integer, String> hashtable = new Hashtable<>();
		hashtable.put(100, "xyz");
		hashtable.put(102, "xyz1");
		hashtable.put(104, "xyz2");
		hashtable.put(105, "xyz4");
		
		hashtable.put(106, null);
		
		System.out.println(hashtable);
		
	}

}
