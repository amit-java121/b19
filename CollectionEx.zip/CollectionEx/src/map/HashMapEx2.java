package map;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMapEx2 {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> hashMap = new HashMap<>();
		
		hashMap.put(100, "ajay");
		hashMap.put(101, "bijay");
		hashMap.put(102, "sanjay");
		hashMap.put(100, "ajay123");
		hashMap.put(null, null);
		hashMap.put(103, null);
		
		//System.out.println(hashMap);
		
//		for(String l:list) {
//			System.out.println(l);
//		}
		
//		for(Entry<Integer, String> map:hashMap.entrySet()) {
//			System.out.println(map.getKey()+" "+map.getValue());
//		}
		
		String value = hashMap.get(100);
		System.out.println(value);
		
	}

}
