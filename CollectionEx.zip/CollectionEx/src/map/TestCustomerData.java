package map;

import java.util.HashMap;

public class TestCustomerData {
	
	public static void main(String[] args) {
		
		PrepareData pd = new PrepareData();
		HashMap<Integer, Customer> customerHash = pd.prepareCustomerData();
		
		
		Customer customerDat = customerHash.get(101010003);
		
		System.out.println(customerDat.toString());
		
	}

}
