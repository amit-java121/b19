package customer;

import java.util.ArrayList;

public class FetchCustomerData {
	
	
	
	public static void main(String[] args) {
	
		PrepareCustomerData pcd = new PrepareCustomerData();
		ArrayList<Customer> listOfCustomers =  pcd.prepareData();
		    //print data here
		    System.out.println(listOfCustomers.toString());
		    
		    
	}

}
