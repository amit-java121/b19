package customer;

import java.util.ArrayList;

public class PrepareCustomerData {
	
	public ArrayList<Customer> prepareData() {
		//will fetch from database
		Customer customer = new Customer();
		customer.setCustomerId(100);
		customer.setCustomerName("Ajay");
		customer.setCustomerGender("male");
		customer.setContactNumber(9898181881l);
		customer.setCustomerAddress("pune");
		
		Customer customer2 = new Customer();
		customer2.setCustomerId(101);
		customer2.setCustomerName("Bjay");
		customer2.setCustomerGender("male");
		customer2.setContactNumber(9898181881l);
		customer2.setCustomerAddress("mumbai");
		
		Customer customer3 = new Customer();
		customer3.setCustomerId(102);
		customer3.setCustomerName("Sagar");
		customer3.setCustomerGender("male");
		customer3.setContactNumber(9898181881l);
		customer3.setCustomerAddress("nagpur");
	
	    ArrayList<Customer> listOfCustomers = new ArrayList<Customer>();
		    
	    listOfCustomers.add(customer);
	    listOfCustomers.add(customer2);
	    listOfCustomers.add(customer3);
	
	    return listOfCustomers;
	}
	
	public int add() {
		int sum = 10+10;
		return sum;
	}

}
