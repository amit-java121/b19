package customer;

public class Customer {
	private int customerId;
	private String customerName;
	private String customerGender;
	private long contactNumber;
	private String customerAddress;
	public int getCustomerId() {
		return customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public String getCustomerGender() {
		return customerGender;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerGender="
				+ customerGender + ", contactNumber=" + contactNumber + ", customerAddress=" + customerAddress + "]";
	}
	
	

}
