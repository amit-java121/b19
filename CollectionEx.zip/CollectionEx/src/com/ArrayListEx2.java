package com;

import java.util.ArrayList;

public class ArrayListEx2 {
	
	public static void main(String[] args) {
		
		ArrayList arrayList = new ArrayList<>();
		
		arrayList.add("Ajay");
		arrayList.add("Bijay");
		arrayList.add("Sanjay");
		arrayList.add("Harish");
		
		//System.out.println(arrayList.size());
		
//		ArrayList arrayList2 = new ArrayList<>();
//		arrayList2.add("abc");
//		arrayList2.add("xyz");
//		
//		arrayList.addAll(arrayList2);
		
		System.out.println(arrayList);//added elements at end
		
		//arrayList.add(0, "xpertit");
		//System.out.println(arrayList);
		
		//arrayList.addAll(2, arrayList2);
		
		System.out.println(arrayList);
		
	}

}
