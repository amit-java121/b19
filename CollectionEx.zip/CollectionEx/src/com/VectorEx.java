package com;

import java.util.Vector;

public class VectorEx {
	
	public static void main(String[] args) {
		
		Vector<String> vector = new Vector<>();
		
		vector.add("ajay");
		vector.addElement("bijay");
		
		System.out.println(vector.capacity());
		
		System.out.println(vector);
		
		for(String obj:vector) {
			System.out.println(obj);
		}
	}

}
