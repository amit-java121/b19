package com;

import java.util.LinkedList;

public class LinkedListEx {
	
	public static void main(String[] args) {
		
		LinkedList<String> linkedList = new LinkedList<>();
		
		linkedList.add("ajay");
		linkedList.add("bijay");
		linkedList.add("harish");
		linkedList.add("sagar");
		
		System.out.println(linkedList);
		linkedList.addFirst("abc");
		System.out.println(linkedList);
		linkedList.push("ababab");
		System.out.println(linkedList);
		linkedList.poll();
		System.out.println(linkedList);
		
		
	}

}
