package com;

import java.util.ArrayList;

public class ArrayListEx {
	
	public static void main(String[] args) {
		
		ArrayList arrayList = new ArrayList();
		
		arrayList.add("Ajay");
		arrayList.add("Bijay");
		arrayList.add("Sanjay");
		arrayList.add("abc");
		arrayList.add("xyz");
		arrayList.add(100);
		arrayList.add(true);
		arrayList.add("abc");
		arrayList.add("xyz");
		
		
		for(int i =0; i<arrayList.size(); i++) {
			System.out.println(arrayList.get(i));
		}
		
	}

}
