package com;

import java.util.ArrayList;

public class ArrayListGenricEx {
	
	public static void main(String[] args) {
		
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("ajay");
		arrayList.add("bijay");
		//arrayList.add(100);
		
		for(int i=0; i<arrayList.size(); i++) {
			
			String name = (String)arrayList.get(i);
			
			if(name.equals("bijay")) {
				System.out.println("process something");
			}
			
			//System.out.println(arrayList.get(i));
		}
	}

}
