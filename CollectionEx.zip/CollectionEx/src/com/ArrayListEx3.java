package com;

import java.util.ArrayList;
import java.util.List;

public class ArrayListEx3 {
	
	public static void main(String[] args) {

		
		ArrayList arrayList = new ArrayList<>();
		
		arrayList.add("Ajay");
		arrayList.add("Bijay");
		arrayList.add("Sanjay");
		arrayList.add("Harish");
		
		ArrayList arrayList2 = new ArrayList<>();
		arrayList2.add("Ajay");
		arrayList2.add("Bijay");
		
		//System.out.println(arrayList.contains("Ajay"));
		
		//System.out.println(arrayList.containsAll(arrayList2));
		
//		for(int i=0; i< arrayList.size(); i++) {
//			System.out.println(arrayList.get(i));
//		}
		
//		for(Object obj:arrayList) { //foreach loop
//			
//			System.out.println(obj.equals("Ajay"));
//		}
		
		//System.out.println(arrayList.get(2));
		
		//System.out.println(arrayList.indexOf("Bijay"));
		
		//System.out.println(arrayList.isEmpty());
		
		//System.out.println(arrayList.remove(1));
		//System.out.println(arrayList.remove("Sanjay"));
		
		//arrayList.removeAll(arrayList2);
		
		//System.out.println(arrayList.retainAll(arrayList2));
		 //  arrayList.clear();
		List subList = arrayList.subList(2, 4);
		System.out.println(subList);
		//System.out.println(arrayList);
		
		
	}

}
