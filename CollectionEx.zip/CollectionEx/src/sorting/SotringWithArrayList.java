package sorting;

import java.util.ArrayList;
import java.util.Collections;

public class SotringWithArrayList {
	
	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("sanjay");
		list.add("sandeep");
		list.add("ajay");
		list.add("bijay");
		list.add("sanjay");
		
		System.out.println("before sorting:::::::::::");
		for(String li : list) {
			System.out.println(li);
		}
		
		Collections.sort(list);
		System.out.println("after sorting:::::::::::");
		for(String li : list) {
			System.out.println(li);
		}
	}

}
