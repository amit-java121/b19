package set;

import java.util.NavigableSet;
import java.util.TreeSet;

public class TreeSetEx {
	
	public static void main(String[] args) {
		
		TreeSet<String> treeSet = new TreeSet<>();
		treeSet.add("sanjay");
		treeSet.add("bijay");
		treeSet.add("ajay");
		treeSet.add("harish");
		//treeSet.add(null);
		
		System.out.println(treeSet);
		NavigableSet<String> reversed = treeSet.descendingSet();
		System.out.println(reversed);
		
		System.out.println(treeSet.ceiling("pavan"));
		System.out.println(treeSet.floor("pavan"));
	
		
	}

}
