package set;

import java.util.HashSet;

public class HashSetEx {
	
	public static void main(String[] args) {
		
		HashSet<String> hashSet = new HashSet<>();
		hashSet.add("anuj");
		hashSet.add("harish");
		hashSet.add("harish");
		hashSet.add("ajay");
		hashSet.add("bijay");
		hashSet.add(null);
		
		System.out.println(hashSet);
		
		HashSet<String> hashSet2 = new HashSet<>();
		hashSet2.add("abc");
		hashSet2.add("xyz");
//		hashSet.addAll(hashSet2);
//		hashSet.addAll(hashSet2);
//		System.out.println(hashSet);
		
		System.out.println(hashSet.containsAll(hashSet2));
		
		//System.out.println(hashSet.retainAll(hashSet2));
		
	}

}
