package set;

import java.util.LinkedHashSet;

public class LinkedHashSetEx {
	
	public static void main(String[] args) {
		
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
		
		linkedHashSet.add("bijay");
		linkedHashSet.add("ajay");
		linkedHashSet.add("sanjay");
		linkedHashSet.add("Pavan");
		linkedHashSet.add("ajay");
		linkedHashSet.add(null);
		System.out.println(linkedHashSet);
		
		
	}

}
