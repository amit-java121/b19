package searching;

public class Employee{
	private int empId;
	private String empName;
	private int contactNumber;
	private String cityName;
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public int getContactNumber() {
		return contactNumber;
	}
	public String getCityName() {
		return cityName;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", contactNumber=" + contactNumber + ", cityName="
				+ cityName + "]";
	}
	

}
