package searching;

import java.util.ArrayList;
import java.util.List;

public class TestEmployee {
	
public List<Employee> prepareEmpData() {
		
		Employee employee = new Employee();
		employee.setEmpId(1000);
		employee.setEmpName("sanjay");
		employee.setContactNumber(897761661);
		employee.setCityName("pune");
		
		Employee employee2 = new Employee();
		employee2.setEmpId(1003);
		employee2.setEmpName("bijay");
		employee2.setContactNumber(897761661);
		employee2.setCityName("mumbai");
		
		Employee employee3 = new Employee();
		employee3.setEmpId(1005);
		employee3.setEmpName("harish");
		employee3.setContactNumber(897761661);
		employee3.setCityName("nagpur");
		
		Employee employee4 = new Employee();
		employee4.setEmpId(1001);
		employee4.setEmpName("tushar");
		employee4.setContactNumber(897761661);
		employee4.setCityName("pune");
		
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(employee);
		employeeList.add(employee2);
		employeeList.add(employee3);
		employeeList.add(employee4);
		
		return employeeList;
	}

	 public List<Employee> filterEmpByCityName() {
		 List<Employee> filteredEmpList = new ArrayList<>();
		 
		 List<Employee> empList = prepareEmpData();
		 //write logic to filter the emp data
		 
		 for(Employee emp:empList) {
			 
			 if(emp.getCityName().equalsIgnoreCase("pune")) {
				 //add element in to new list
				 filteredEmpList.add(emp);
			 }
			 
		 }
		 
		 //filteredEmpList = empList.stream().filter(obj ->obj.getCityName().equalsIgnoreCase("mumbai")).collect(Collectors.toList());
		 
		 return filteredEmpList;
	 }
	 
	 public static void main(String[] args) {
		 TestEmployee te = new TestEmployee();
		 
		List<Employee> filteredList = te.filterEmpByCityName();
		 //print filtered emp list here
		System.out.println(filteredList.toString());
	}

}
