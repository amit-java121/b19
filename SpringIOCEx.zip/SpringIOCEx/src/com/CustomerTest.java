package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class CustomerTest {
	
	public static void main(String[] args) {
//		Customer customer = new Customer();
//		customer.printData();
		
		Resource resource = new ClassPathResource("applicationContext.xml");
		BeanFactory beanFactory = new XmlBeanFactory(resource);
		
		Customer customer = (Customer)beanFactory.getBean("cust");
		customer.printData();
		
		
		Employee emp = (Employee)beanFactory.getBean("emp");
		emp.getEmp();
		
	}

}
