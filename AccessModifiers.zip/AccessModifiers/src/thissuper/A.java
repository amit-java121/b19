package thissuper;

public class A {
	
	int a =10;
	
	public void m1() {
		
		System.out.println(this.a);
	}
	
	public void m2() {
		this.m1();
	}
	
	A(int a,int b){
		
	}

}
