package thissuper;

public class B extends A{
	
	public void m1() {
		
	}
	
	public void test() 
	{
		super.m1();
	}
	
	B(){
	 super(10,20);	
	}

}
