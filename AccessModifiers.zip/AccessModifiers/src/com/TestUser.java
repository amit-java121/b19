package com;

public class TestUser {
	
	public static void main(String[] args) {
		
		User user = new User();
		
		
	}

}
