package com;

public class User {
	
	private int userId;
	
	
	public User() {
		
	}
	
	public void getUserId(int userid) {
		getUserDetails(userid);
	}
	
	private String getUserDetails(int userid) {
		
		return "";
	}
	
	public static void main(String[] args) {
		
		User user = new User();
		System.out.println(user.userId);
		user.getUserId(100);
	}

}
