package com;

public class B {
	
	protected int id = 100;
	
	protected void test() {
		
	}
	
	public void test2() {
		
	}
	
	public B(){
		
	}

}
