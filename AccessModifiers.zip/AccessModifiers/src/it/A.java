package it;

import com.B;

public class A extends B{
	
	public void m1() {
		
		//B b = new B();
	    //b.test2();
	    A a = new A();
	    
		
		
	}

}
